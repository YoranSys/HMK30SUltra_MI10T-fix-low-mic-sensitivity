#  HMK30SUltra MI10T fix low mic sensitivity 

Github link: https://github.com/YoranSys/HMK30SUltra_MI10T-fix-low-mic-sensitivity

## Changelog

* v1.0 (05.08.2022) - Initial release
* 
