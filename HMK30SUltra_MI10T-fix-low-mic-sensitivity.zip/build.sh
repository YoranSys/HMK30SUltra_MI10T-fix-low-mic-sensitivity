#!/usr/bin/env bash

zip HMK30SUltra_MI10T-fix-low-mic-sensitivity.zip *