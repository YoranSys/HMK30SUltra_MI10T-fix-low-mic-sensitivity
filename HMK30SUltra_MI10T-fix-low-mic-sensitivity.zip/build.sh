#!/usr/bin/env bash

zip -r HMK30SUltra_MI10T-fix-low-mic-sensitivity.zip *
